# Calculadora de BTU – Oasis
Este sitio está listo para desplegar en **GitHub Pages** o **Netlify**.

## GitHub Pages (rápido)
1. Crea un repositorio nuevo llamado `oasis-btu` (público).
2. Sube `index.html` (arrastrar y soltar en GitHub).
3. Ve a **Settings → Pages** y en *Build and deployment* selecciona **Deploy from a branch**.
4. Branch: `main` (o `master`) y carpeta `/root`.
5. La página quedará en: `https://TU-USUARIO.github.io/oasis-btu/`

## Netlify (muy fácil)
1. Entra a https://app.netlify.com/ y elige **Add new site → Deploy manually**.
2. Arrastra el archivo `index.html` (o sube el .zip).
3. Obtendrás una URL tipo `https://oasis-btu.netlify.app/`.

## Incrustar en tu web (design.com)
Usa un widget de **Código HTML** con:
```html
<iframe src="https://TU-URL/index.html" style="width:100%;max-width:720px;border:0;height:880px;border-radius:12px;overflow:hidden;"></iframe>
```
